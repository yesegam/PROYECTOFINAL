/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carritodecompras;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class ArchivoUsuarios {

    private static final String ARCHIVO_USUARIOS = "data/usuarios.txt";

    // Método para escribir un nuevo usuario en el archivo
    public static void escribirUsuario(Usuario usuario) throws IOException {
        try (PrintWriter pw = new PrintWriter(new FileWriter(ARCHIVO_USUARIOS, true))) {
            pw.println(usuario.getNombre() + "," + usuario.getContraseña());
        }
    }

    // Método para validar un usuario y contraseña
    public static boolean validarUsuario(String nombre, String contraseña) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(ARCHIVO_USUARIOS))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                if (datos.length == 2 && datos[0].equals(nombre) && datos[1].equals(contraseña)) {
                    return true; // Usuario y contraseña válidos
                }
            }
        }
        return false; // Usuario no encontrado o contraseña incorrecta
    }
}

